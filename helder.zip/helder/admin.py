# from django.contrib import admin
# Register your models here.
# from .models import Photo, Category,Pattern,Type

# admin.site.register(Category)
# admin.site.register(Photo)
# admin.site.register(Pattern)
# admin.site.register(Type)